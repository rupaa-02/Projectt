const express = require("express");
const router = express.Router();
const borrowingController = require("../controllers/borrowingController");
const authenticate = require("../middlewares/authMiddleware"); // JWT Auth

router.get("/", authenticate, borrowingController.getAllBorrowings);
router.post("/", authenticate, borrowingController.createBorrowing);
router.put("/:id/return", authenticate, borrowingController.returnBook);
router.get("/overdue", authenticate, borrowingController.getOverdueBorrowings);
router.get("/member/:memberId", authenticate, borrowingController.getAllBorrowings);

module.exports = router;
