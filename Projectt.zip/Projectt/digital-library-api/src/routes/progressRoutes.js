const express = require("express");
const router = express.Router();
const progressController = require("../controllers/progressController");
const authenticate = require("../middlewares/authMiddleware"); // JWT Auth

router.get("/:borrowingId", authenticate, progressController.getReadingProgress);
router.post("/", authenticate, progressController.updateReadingProgress);
router.get("/analytics/member/:memberId", authenticate, progressController.getReadingAnalytics);

module.exports = router;
