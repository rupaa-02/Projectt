const express = require("express");
const router = express.Router();
const bookController = require("../controllers/bookController");
const authenticate = require("../middlewares/authMiddleware"); // JWT Auth

router.get("/", bookController.getAllBooks);
router.get("/:id", bookController.getBookById);
router.get("/genre/:genre", bookController.getAllBooks); // Get books by genre
router.post("/", authenticate, bookController.addBook);
router.put("/:id", authenticate, bookController.updateBook);

module.exports = router;
