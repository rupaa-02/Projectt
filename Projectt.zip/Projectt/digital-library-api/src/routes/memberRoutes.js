const express = require("express");
const router = express.Router();
const memberController = require("../controllers/memberController");
const authenticate = require("../middlewares/authMiddleware"); // JWT Auth

router.get("/", authenticate, memberController.getAllMembers);
router.get("/:id", authenticate, memberController.getMemberById);
router.post("/", memberController.addMember); // Registration should be open
router.put("/:id", authenticate, memberController.updateMember);
router.get("/:id/history", authenticate, memberController.getMemberHistory);

module.exports = router;
