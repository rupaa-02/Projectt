const { DataTypes } = require("sequelize");

module.exports = (sequelize) => {
  const Progress = sequelize.define("Progress", {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    borrowingId: { type: DataTypes.UUID, allowNull: false, references: { model: "Borrowings", key: "id" } },
    currentPage: { type: DataTypes.INTEGER, allowNull: false },
    lastReadDate: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW },
    readingTime: { type: DataTypes.INTEGER, allowNull: false },
    notes: { type: DataTypes.TEXT },
  });

  return Progress;
};
