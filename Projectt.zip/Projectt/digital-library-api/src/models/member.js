const { DataTypes } = require("sequelize");

module.exports = (sequelize) => {
  const Member = sequelize.define("Member", {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    name: { type: DataTypes.STRING, allowNull: false },
    email: { type: DataTypes.STRING, allowNull: false, unique: true },
    membershipType: {
      type: DataTypes.ENUM("standard", "premium"),
      allowNull: false,
    },
    joinDate: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW },
    status: {
      type: DataTypes.ENUM("active", "suspended"),
      allowNull: false,
      defaultValue: "active",
    },
  });

  return Member;
};
