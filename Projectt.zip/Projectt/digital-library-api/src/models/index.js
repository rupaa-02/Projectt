const { Sequelize } = require("sequelize");
const sequelize = require("../config/database");

const Book = require("./book")(sequelize);
const Member = require("./member")(sequelize);
const Borrowing = require("./borrowing")(sequelize);
const Progress = require("./progress")(sequelize);

// Associations
Book.hasMany(Borrowing, { foreignKey: "bookId" });
Borrowing.belongsTo(Book, { foreignKey: "bookId" });

Member.hasMany(Borrowing, { foreignKey: "memberId" });
Borrowing.belongsTo(Member, { foreignKey: "memberId" });

Borrowing.hasOne(Progress, { foreignKey: "borrowingId" });
Progress.belongsTo(Borrowing, { foreignKey: "borrowingId" });

module.exports = { sequelize, Book, Member, Borrowing, Progress };
