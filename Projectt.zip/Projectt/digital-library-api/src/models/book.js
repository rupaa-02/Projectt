const { DataTypes } = require("sequelize");

module.exports = (sequelize) => {
  const Book = sequelize.define("Book", {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    isbn: { type: DataTypes.STRING, allowNull: false, unique: true },
    title: { type: DataTypes.STRING, allowNull: false },
    author: { type: DataTypes.STRING, allowNull: false },
    genre: { type: DataTypes.STRING, allowNull: false },
    publicationYear: { type: DataTypes.INTEGER, allowNull: false },
    totalCopies: { type: DataTypes.INTEGER, allowNull: false },
    availableCopies: { type: DataTypes.INTEGER, allowNull: false },
  });

  return Book;
};
