const { DataTypes } = require("sequelize");

module.exports = (sequelize) => {
  const Borrowing = sequelize.define("Borrowing", {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    bookId: { type: DataTypes.UUID, allowNull: false, references: { model: "Books", key: "id" } },
    memberId: { type: DataTypes.UUID, allowNull: false, references: { model: "Members", key: "id" } },
    borrowDate: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW },
    dueDate: { type: DataTypes.DATE, allowNull: false },
    returnDate: { type: DataTypes.DATE },
    status: {
      type: DataTypes.ENUM("active", "returned", "overdue"),
      allowNull: false,
      defaultValue: "active",
    },
  });

  return Borrowing;
};
