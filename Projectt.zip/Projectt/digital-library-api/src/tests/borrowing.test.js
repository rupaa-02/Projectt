const axios = require("axios");

const BASE_URL = "http://localhost:5000/api";
const TOKEN = "your_jwt_token_here";
const BOOK_ID = "valid_book_id_here"; // Replace with a real book ID
const MEMBER_ID = "valid_member_id_here"; // Replace with a real member ID

async function testCreateBorrowing() {
  try {
    const response = await axios.post(
      `${BASE_URL}/borrowings`,
      {
        bookId: BOOK_ID,
        memberId: MEMBER_ID,
        dueDate: "2025-03-10",
      },
      { headers: { Authorization: `Bearer ${TOKEN}` } }
    );
    console.log("✅ Borrowing Created:", response.data);
  } catch (error) {
    console.error("❌ Error creating borrowing:", error.response?.data || error.message);
  }
}

// Run test
testCreateBorrowing();
