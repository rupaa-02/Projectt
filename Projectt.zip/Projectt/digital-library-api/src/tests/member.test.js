const axios = require("axios");

const BASE_URL = "http://localhost:5000/api";
const TOKEN = "your_jwt_token_here";

async function testGetMembers() {
  try {
    const response = await axios.get(`${BASE_URL}/members`, {
      headers: { Authorization: `Bearer ${TOKEN}` },
    });
    console.log("✅ Get Members:", response.data);
  } catch (error) {
    console.error("❌ Error getting members:", error.response?.data || error.message);
  }
}

async function testRegisterMember() {
  try {
    const response = await axios.post(
      `${BASE_URL}/members`,
      {
        name: "John Doe",
        email: "johndoe@example.com",
        membershipType: "standard",
      },
      { headers: { Authorization: `Bearer ${TOKEN}` } }
    );
    console.log("✅ Member Registered:", response.data);
  } catch (error) {
    console.error("❌ Error registering member:", error.response?.data || error.message);
  }
}

// Run tests
(async () => {
  await testGetMembers();
  await testRegisterMember();
})();
