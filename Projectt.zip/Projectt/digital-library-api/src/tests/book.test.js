const axios = require("axios");

const BASE_URL = "http://localhost:5000/api"; // Update with your actual API URL
const TOKEN = "your_jwt_token_here"; // Replace with a valid token

async function testGetBooks() {
  try {
    const response = await axios.get(`${BASE_URL}/books`, {
      headers: { Authorization: `Bearer ${TOKEN}` },
    });
    console.log("✅ Get Books:", response.data);
  } catch (error) {
    console.error("❌ Error getting books:", error.response?.data || error.message);
  }
}

async function testAddBook() {
  try {
    const response = await axios.post(
      `${BASE_URL}/books`,
      {
        title: "Test Book",
        author: "Test Author",
        isbn: "1234567890",
        genre: "Fiction",
        publicationYear: 2022,
        totalCopies: 5,
        availableCopies: 5,
      },
      { headers: { Authorization: `Bearer ${TOKEN}` } }
    );
    console.log("✅ Book Added:", response.data);
  } catch (error) {
    console.error("❌ Error adding book:", error.response?.data || error.message);
  }
}

// Run tests
(async () => {
  await testGetBooks();
  await testAddBook();
})();

