const axios = require("axios");

const BASE_URL = "http://localhost:5000/api";
const TOKEN = "your_jwt_token_here";
const BORROWING_ID = "valid_borrowing_id_here"; // Replace with a real borrowing ID

async function testUpdateReadingProgress() {
  try {
    const response = await axios.post(
      `${BASE_URL}/progress`,
      {
        borrowingId: BORROWING_ID,
        currentPage: 50,
        readingTime: 30,
        notes: "Interesting chapter!",
      },
      { headers: { Authorization: `Bearer ${TOKEN}` } }
    );
    console.log("✅ Reading Progress Updated:", response.data);
  } catch (error) {
    console.error("❌ Error updating progress:", error.response?.data || error.message);
  }
}

// Run test
testUpdateReadingProgress();
