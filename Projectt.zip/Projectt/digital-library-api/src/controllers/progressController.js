const { Progress } = require("../models");

// Get reading progress
exports.getReadingProgress = async (req, res) => {
  try {
    const progress = await Progress.findOne({ where: { borrowingId: req.params.borrowingId } });
    if (!progress) return res.status(404).json({ error: "Progress not found" });

    res.json(progress);
  } catch (error) {
    res.status(500).json({ error: "Error fetching reading progress" });
  }
};

// Update reading progress
exports.updateReadingProgress = async (req, res) => {
  try {
    const progress = await Progress.create(req.body);
    res.status(201).json(progress);
  } catch (error) {
    res.status(400).json({ error: "Error updating progress" });
  }
};

// Get member’s reading analytics
exports.getReadingAnalytics = async (req, res) => {
  try {
    const analytics = await Progress.findAll({ where: { borrowingId: req.params.memberId } });
    res.json(analytics);
  } catch (error) {
    res.status(500).json({ error: "Error fetching analytics" });
  }
};
