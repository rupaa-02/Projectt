const { Member, Borrowing } = require("../models");

// Get all members with pagination
exports.getAllMembers = async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    const members = await Member.findAndCountAll({
      limit: parseInt(limit),
      offset: parseInt(offset),
    });

    res.json({ total: members.count, members: members.rows });
  } catch (error) {
    res.status(500).json({ error: "Error fetching members" });
  }
};

// Get member by ID with current borrowings
exports.getMemberById = async (req, res) => {
  try {
    const member = await Member.findByPk(req.params.id, {
      include: [{ model: Borrowing }],
    });

    if (!member) return res.status(404).json({ error: "Member not found" });

    res.json(member);
  } catch (error) {
    res.status(500).json({ error: "Error fetching member details" });
  }
};

// Register a new member
exports.addMember = async (req, res) => {
  try {
    const member = await Member.create(req.body);
    res.status(201).json(member);
  } catch (error) {
    res.status(400).json({ error: "Invalid member data" });
  }
};

// Update member details
exports.updateMember = async (req, res) => {
  try {
    const member = await Member.findByPk(req.params.id);
    if (!member) return res.status(404).json({ error: "Member not found" });

    await member.update(req.body);
    res.json(member);
  } catch (error) {
    res.status(400).json({ error: "Error updating member" });
  }
};

// Get member borrowing history
exports.getMemberHistory = async (req, res) => {
  try {
    const history = await Borrowing.findAll({ where: { memberId: req.params.id } });
    res.json(history);
  } catch (error) {
    res.status(500).json({ error: "Error fetching history" });
  }
};
