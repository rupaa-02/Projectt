const { Book } = require('D:\Projectt\digital-library-api\src\controllers\bookController.js');

// Get all books with pagination & optional genre filter
exports.getAllBooks = async (req, res) => {
  try {
    const { page = 1, limit = 10, genre } = req.query;
    const offset = (page - 1) * limit;
    const filter = genre ? { genre } : {};

    const books = await Book.findAndCountAll({
      where: filter,
      limit: parseInt(limit),
      offset: parseInt(offset),
    });

    res.json({ total: books.count, books: books.rows });
  } catch (error) {
    res.status(500).json({ error: "Error fetching books" });
  }
};

// Get book by ID
exports.getBookById = async (req, res) => {
  try {
    const book = await Book.findByPk(req.params.id);
    if (!book) return res.status(404).json({ error: "Book not found" });

    res.json(book);
  } catch (error) {
    res.status(500).json({ error: "Error fetching book details" });
  }
};

// Add a new book
exports.addBook = async (req, res) => {
  try {
    const book = await Book.create(req.body);
    res.status(201).json(book);
  } catch (error) {
    res.status(400).json({ error: "Invalid book data" });
  }
};

// Update book details
exports.updateBook = async (req, res) => {
  try {
    const book = await Book.findByPk(req.params.id);
    if (!book) return res.status(404).json({ error: "Book not found" });

    await book.update(req.body);
    res.json(book);
  } catch (error) {
    res.status(400).json({ error: "Error updating book" });
  }
};
