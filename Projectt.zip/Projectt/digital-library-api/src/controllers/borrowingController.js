const { Borrowing, Book } = require("../models");

// Get all borrowings
exports.getAllBorrowings = async (req, res) => {
  try {
    const borrowings = await Borrowing.findAll();
    res.json(borrowings);
  } catch (error) {
    res.status(500).json({ error: "Error fetching borrowings" });
  }
};

// Create a new borrowing
exports.createBorrowing = async (req, res) => {
  try {
    const book = await Book.findByPk(req.body.bookId);
    if (!book || book.availableCopies <= 0) {
      return res.status(400).json({ error: "Book unavailable" });
    }

    const borrowing = await Borrowing.create(req.body);
    await book.update({ availableCopies: book.availableCopies - 1 });

    res.status(201).json(borrowing);
  } catch (error) {
    res.status(400).json({ error: "Error creating borrowing" });
  }
};

// Process a return
exports.returnBook = async (req, res) => {
  try {
    const borrowing = await Borrowing.findByPk(req.params.id);
    if (!borrowing || borrowing.status !== "active") {
      return res.status(400).json({ error: "Invalid return" });
    }

    await borrowing.update({ returnDate: new Date(), status: "returned" });

    const book = await Book.findByPk(borrowing.bookId);
    await book.update({ availableCopies: book.availableCopies + 1 });

    res.json({ message: "Book returned successfully" });
  } catch (error) {
    res.status(400).json({ error: "Error processing return" });
  }
};

// Get overdue borrowings
exports.getOverdueBorrowings = async (req, res) => {
  try {
    const overdue = await Borrowing.findAll({
      where: { status: "overdue" },
    });
    res.json(overdue);
  } catch (error) {
    res.status(500).json({ error: "Error fetching overdue borrowings" });
  }
};
