const { Sequelize } = require("sequelize");
require("dotenv").config(); // Load environment variables

// Initialize Sequelize with database credentials from .env
const sequelize = new Sequelize(process.env.DB_URL, {
  dialect: "postgres", // Specify PostgreSQL as the database type
  logging: false, // Set to 'console.log' to enable logging
});

// Test the database connection
(async () => {
  try {
    await sequelize.authenticate();
    console.log("✅ Database connection established successfully.");
  } catch (error) {
    console.error("❌ Unable to connect to the database:", error);
  }
})();

module.exports = sequelize;
