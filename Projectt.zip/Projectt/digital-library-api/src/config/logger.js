const morgan = require("morgan");

// Use 'dev' format for concise logging of HTTP requests
const logger = morgan("dev");

module.exports = logger;
