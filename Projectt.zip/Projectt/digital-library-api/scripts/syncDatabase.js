const { sequelize } = require("../models");

(async () => {
  try {
    await sequelize.sync({ force: true }); // Use `force: false` to prevent data loss
    console.log("✅ Database tables created successfully.");
    process.exit();
  } catch (error) {
    console.error("❌ Error creating tables:", error);
    process.exit(1);
  }
})();
